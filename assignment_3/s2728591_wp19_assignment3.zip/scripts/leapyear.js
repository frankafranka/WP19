function allLetters(variable){
    if(variable.match(/^[A-Za-z]+$/)){
        variable.removeClass("invalid-feedback");
        variable.addClass("valid-feedback");
        return true;
    }
    else {
        variable.removeClass("valid-feedback");
        variable.addClass("invalid-feedback");
        return false;
    }
}

function allNumbers(variable){
    if(variable.match(/^[0-9]+$/)){
        variable.removeClass("invalid-feedback");
        variable.addClass("valid-feedback");
        return true;
    }
    else {
        variable.removeClass("valid-feedback");
        variable.addClass("invalid-feedback");
        return false;
    }
}

function checkEmail(variable) {
    if (variable.match(/^[a-zA-Z0-9.!#$%&’*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/)) {
        variable.removeClass("invalid-feedback");
        variable.addClass("valid-feedback");
        return true;
    } else {
        variable.removeClass("valid-feedback");
        variable.addClass("invalid-feedback");
    }
}

function checkAll(){
    let name = $('#name');
    let age = $('#age');
    let email = $('#email');
    let place = $('#place');

    if(allLetters(name) && allLetters(place) &&  allNumbers(age) && checkEmail(email)){
        $("#leapyearForm").submit();
    }
}

window.onload = function() {
    $("#submit").click(function () {
        checkAll();
    });
}





