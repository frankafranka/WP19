<?php
/* Header */
$page_title = 'Webprogramming Assignment 3';
$navigation = Array(
    'active' => 'Simple Form',
    'items' => Array(
        'News' => '/~s2728591/WP19/assignment_3/index.php',
        'Add news item' => '/~s2728591/WP19/assignment_3/news_add.php',
        'Edit news item' => '/~s2728591/WP19/assignment_3/news_edit.php',
        'Leap Year' => '/~s2728591/WP19/assignment_3/leapyear.php',
        'Simple Form' => '/~s2728591/WP19/assignment_3/simple_form.php'
    )
);
include __DIR__ . '/tpl/head.php';
include __DIR__ . '/tpl/body_start.php';
?>

<?php
$name = $_GET['fullname'];
$place = $_GET['place'];
?>

<h1> <?php echo 'Welcome ' .$name. '!'?></h1>
<p> <?php
    if ($place == 'Amsterdam'){echo 'You are form the capital from Amsterdam!';}
    else{ echo 'You are from '.$place.'!';} ?>
</p>

<div class="row wp-row">
    <div class="col-md-12">
        <form id="myForm" action="#" method="GET">
            <label for="fullname">Name:</label>
            <input type="text" id="fulllname" name="fullname">
            <label for="place">Place:</label>
            <input type="text" id="place" name="place">
            <button type="submit" id="subButton">Submit</button>
        </form>
    </div>
</div>


<?php
include __DIR__ . '/tpl/body_end.php';
?>
