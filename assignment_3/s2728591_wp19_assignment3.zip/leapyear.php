<?php
/* Header */
$page_title = 'Webprogramming Assignment 3';
$navigation = Array(
    'active' => 'Leap Year',
    'items' => Array(
        'News' => '/~s2728591/WP19/assignment_3/index.php',
        'Add news item' => '/~s2728591/WP19/assignment_3/news_add.php',
        'Edit news item' => '/~s2728591/WP19/assignment_3/news_edit.php',
        'Leap Year' => '/~s2728591/WP19/assignment_3/leapyear.php',
        'Simple Form' => '/~s2728591/WP19/assignment_3/simple_form.php',
    )
);
?>

<?php
include __DIR__ . '/tpl/head.php';
include __DIR__ . '/tpl/body_start.php';
?>

<?php
$name = $_POST['name'];
$age = $_POST['age'];
$email = $_POST['email'];
$place = $_POST['place'];
?>
    <h1>
        <?php echo 'Welcome '.$name.'!' ?>
    </h1>

    <p>The next 5 leap years, this will be your age!</p>

    <p>
        <?php
        if ($place == 'Groningen'){
            echo 'Nice, you are living in Groningen!';
            }
        ?>
    </p>

    <table class="table">
        <thead>
         <tr>
             <th scope="col">Year</th>
             <th scope="col">Age</th>
        </tr>
        </thead>
        <tbody>
        <tr>
            <th scope="row">2024</th>
            <td>
                <?php echo ($age + 5) ?>
            </td>
        </tr>
        <tr>
            <th scope="row">2028</th>
            <td>
                <?php echo ($age + 9)?>
                </td>
        </tr>
        <tr>
            <th scope="row">2032</th>
            <td>
             <?php echo ($age + 13) ?>
            </td>
        </tr>
        <tr>
            <th scope="row">2036</th>
            <td>
                <?php echo ($age + 17) ?>
            </td>
        </tr>
        <tr>
            <th scope="row">2040</th>
            <td>
                <?php echo ($age + 21) ?>
            </td>
        </tr>
        </tbody>
    </table>

    <div class="container">
        <form action="#" method="POST" id="leapyearForm" class="was-validated">
            <div class="form-group">
                <label for="name">Name:</label>
                <input type="text" class="form-control" id="name"
                       placeholder="Enter Name" name="name" required>
                <div class="valid-feedback">Valid</div>
                <div class="invalid-feedback">
                    Please fill this field
                </div>
            </div>

            <div class="form-group">
                <label for="email">Email:</label>
                <input type="email" class="form-control" id="email"
                       placeholder="Enter Email" name="email" required>
                <div class="valid-feedback">Valid</div>
                <div class="invalid-feedback">
                    Please fill this field according to the example: mark@mail.com
                </div>
            </div>

            <div class="form-group">
                <label for="age">Age:</label>
                <input type="text" class="form-control" id="age"
                       placeholder="Enter Age" name="age" required>
                <div class="valid-feedback">Valid</div>
                <div class="invalid-feedback">
                    Please fill this field, use numbers only
                </div>
            </div>

            <div class="form-group">
                <label for="place">Place:</label>
                <input type="text" class="form-control" id="place"
                       placeholder="Enter Place" name="place" required>
                <div class="valid-feedback">Valid</div>
                <div class="invalid-feedback">
                    Please fill this field
                </div>
            </div>

            <button type="submit" id="submit" class="btn btn-primary">Show me!</button>
        </form>
    </div>
    <script src="../assignment_3/scripts/leapyear.js"></script>
<?php
include __DIR__ . '/tpl/body_end.php';
?>