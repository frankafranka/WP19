function validateForm(){

    // variables for data in form fields
    let name = $("#name-data").val();
    let email = $("#email-data").val();
    let age = $("#age-data").val();
    let live = $("#live-data").val();
    let phone = $("#tel-data").val();

    // regular expressions for validation
    let numbers = /^[0-9]+$/;
    let letters = /^[A-Za-z]+$/;
    let emailRE = /^[a-zA-Z0-9.!#$%&’*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/;

    // this function checks whether all fields contain content
    function allFields(){
        let isValid = true;
        $('.form-control').each(function(){
            if ($(this).val() === '')
                isValid = false;
        });
        return isValid;
    }

    // this function takes data (form-content) and a regular expression as arguments and then checks whether it matches
    function check(variable, checkfor){
        if(variable.match(checkfor))
        {
            return true;
        }
        else
        {
            return false;
        }
    }

    // variables for the checks that have to happen,
    let checkName = check(name, letters);
    let checkLive = check(live, letters);
    let checkAge = check(age, numbers);
    let checkPhone = check(phone, numbers);
    let checkEmail = check(email, emailRE);

    // errorlist to use as feedback when form is not validated
    var errorList = [];

    // condition checks, every false condition is added to the errorlist
    if (allFields() == false){
        errorList.push("Not all fields are filled in, please do so");}
    else {
        if (checkName = false){
            errorList.push("Use only letters in Name");}
        if (checkLive == false){
            errorList.push("Use only letters for the city");}
        if (checkAge == false){
            errorList.push("Use only numbers for your age");}
        if (checkPhone == false){
            errorList.push("Use only numbers for your phonenumber");}
        if (checkEmail == false){
            errorList.push("Use the example format for your e-mail: name@example.com");}
    };

    // condition if the errorlist is empty it means the form is validated so returns true, else it returns the list
    if (errorList.length < 1){
        return true;
    }
    else {
        return errorList;
    };

}


function writeFormData(){

    let name = $("#name-data").val();
    let email = $("#email-data").val();
    let age = $("#age-data").val();
    let live = $("#live-data").val();
    let phone = $("#tel-data").val();


    let FormData = {
        name: name,
        email: email,
        age: age,
        live: live,
        phone: phone
    };

    return FormData;
}

$(function() {

    $("#submit").click(function(){
        writeFormData();

        if (validateForm()== true){
            $("#form-alert").hide();
            $("#form-content").show();

            let table = document.getElementById("form-content").firstElementChild;
            var x = table.rows[0].cells;
            x[1].innerHTML = $("#name-data").val();
            var x = table.rows[1].cells;
            x[1].innerHTML = $("#age-data").val();
            var x = table.rows[2].cells;
            x[1].innerHTML = $("#live-data").val();
            var x = table.rows[3].cells;
            x[1].innerHTML = $("#email-data").val();
            var x = table.rows[4].cells;
            x[1].innerHTML = $("#tel-data").val();

        }
        else{
            document.getElementById("form-alert").innerHTML = validateForm();

            $('#form-alert').show();
        };

    });

    $("#erase").click(function(){
        $("#form-alert").hide();
        $("#form-content").hide();
        document.getElementById("myForm").reset();
    })

//    let the tabs work
    $("#link-tab").click(function(){
        $("#contact").hide();
        $("#links").show();
    });
    $("#contact-tab").click(function(){
        $("#links").hide();
        $("#contact").show();
    });

});