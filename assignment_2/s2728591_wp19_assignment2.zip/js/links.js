function addList() {
    $('#linkTitle').append('<ul id="list1"></ul>');
    $('#list1').append('<li><a href="https://google.com">Google</a></li>');
    $('#list1').append('<li><a href="https://facebook.com">Facebook</a></li>');
    $('#list1').append('<li><a href="https://instagram.com">Instagram</a></li>');
    $('#list1').append('<li><a href="https://twitter.com">Twitter</a></li>');
}

function addButtonToggle() {
    $(".col-md-12").append('<button id="buttonToggle">Show or hide list</button>');
    $("#buttonToggle").click(function(){
        $("#list1").toggle();
    })
}

function allFields(){
    let isValid = true;
    $('.form-control').each(function(){
        if ($(this).val() === '')
            isValid = false;
    });
    return isValid;
}

function addInput(){
    $(".col-md-12").append('<input id="link-data" class="form-control" type="text" placeholder="Link Name">');
    $(".col-md-12").append('<input id="url-data" class="form-control" type="text" placeholder="URL">');
    allFields()

    $(".col-md-12").append('<button id="buttonAdd">Add list item</button>');
    if (allFields() == false){
        alert("Please fill in all fields")}
    else{
        $("#buttonAdd").click(function(){
            $("#list1").append($('<li>', {
                text: $('#url-data').val()
            }));
         });
    }
}

function addDeletemode(){
    $(".col-md-12").append('<button id="delete-button">Delete mode</button>');
    $("delete-button").click(function(){
        $(this).hide();
    })
}


$(function() {
    addList();
    addButtonToggle();
    addInput();
    addDeletemode();
});